"""Replay a byte-verified historical module in memory; never overwrite source."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import sys
import types

sys.path.insert(0, str(Path.cwd()))
here = Path(__file__).resolve().parent
source = here / "pta-abstractkey-red-source.py"
expected = "d5669b2e381c1aae95a40775e3204933923710e0f8681485fe92c44393a16462"
assert hashlib.sha256(source.read_bytes()).hexdigest() == expected
name = "pythonstan.analysis.composition.region_engine_review_red"
module = types.ModuleType(name)
module.__file__ = str(source)
sys.modules[name] = module
exec(compile(source.read_text(), str(source), "exec"), module.__dict__)
from tests.regression.audit3 import test_pta02_review_resume2 as checks
checks.NativeRegionEngine = module.NativeRegionEngine
try:
    checks.test_one_abstract_literal_key_still_has_one_entry_in_each_concrete_map()
except UnboundLocalError as error:
    assert "item" in str(error)
    print(json.dumps({"reproduced": True, "exception": "UnboundLocalError", "exact_red_source": expected}))
else:
    raise AssertionError("Historical abstract-key counterexample no longer reproduced")
